# TDD Log

## Slice 1 — health, menu shell, module behavior

### RED
- Command: `.venv/bin/pytest -q`
- Result: exit 2; `ModuleNotFoundError: No module named 'hermes_sales'`
- Collection errors: 2

### GREEN
- Implemented FastAPI app, SQLite repository, five-module API/UI.
- Command: `.venv/bin/pytest -q`
- Result: 8 passed, 0 failed.

## Slice 2 — deploy package and Oracle schema

### RED
- Command: `.venv/bin/pytest -q tests/test_deployment.py`
- Result: 4 failed; required DDL/deploy artifacts did not exist.

### GREEN
- Implemented Oracle schema, seed, environment template, systemd, Nginx TLS, and preflight/install/verify/rollback scripts.
- Command: `.venv/bin/pytest -q`
- Result: 12 passed, 0 failed; clean run after aligning Starlette test dependency with `httpx2>=2,<3`.
- Clean wheel verification: installed `hermes_sales_platform-0.1.0-py3-none-any.whl` in a new venv; import PASS; `/healthz` returned HTTP 200.

## Slice 3 — Demo URL scheme hardening

### RED
- Added a `javascript://docs.oracle.com/...` case; endpoint incorrectly returned HTTP 201.

### GREEN
- Restricted Demo URLs to HTTPS plus the Oracle hostname allowlist.
- Full result: 12 passed, 0 failed; Ruff PASS.
