#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
[[ $(id -u) -eq 0 ]] || { echo 'run as root' >&2; exit 1; }
command -v nginx >/dev/null || { echo 'nginx is required' >&2; exit 1; }

install -d -m 0750 /etc/hermes-sales /etc/hermes-sales/secrets
if [[ -e /etc/systemd/system/hermes-sales.service ]]; then
  cp -a /etc/systemd/system/hermes-sales.service "/etc/systemd/system/hermes-sales.service.$STAMP.bak"
fi
if [[ -e /etc/nginx/conf.d/hermes-sales.conf ]]; then
  cp -a /etc/nginx/conf.d/hermes-sales.conf "/etc/nginx/conf.d/hermes-sales.conf.$STAMP.bak"
fi
install -o root -g root -m 0644 "$SCRIPT_DIR/hermes-sales.service" /etc/systemd/system/hermes-sales.service
install -o root -g root -m 0644 "$SCRIPT_DIR/nginx-hermes-sales.conf" /etc/nginx/conf.d/hermes-sales.conf
nginx -t
systemctl daemon-reload
systemctl reload nginx
printf 'PASS: host templates installed; firewall, NSG, DNS and certificates were not modified\n'
