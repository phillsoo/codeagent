#!/usr/bin/env bash
set -euo pipefail

RELEASE_ARCHIVE=${1:?usage: install.sh RELEASE_TAR_GZ VERSION}
VERSION=${2:?usage: install.sh RELEASE_TAR_GZ VERSION}
BASE=/opt/hermes-sales
RELEASE="$BASE/releases/$VERSION"
[[ $(id -u) -eq 0 ]] || { echo 'run as root' >&2; exit 1; }
[[ -f "$RELEASE_ARCHIVE" ]] || { echo 'archive not found' >&2; exit 1; }
[[ "$VERSION" =~ ^[0-9A-Za-z._-]+$ ]] || { echo 'invalid version' >&2; exit 1; }
getent passwd hermes-sales >/dev/null || useradd --system --home-dir /var/lib/hermes-sales --shell /sbin/nologin hermes-sales
install -d -o hermes-sales -g hermes-sales -m 0750 "$BASE/releases" /var/lib/hermes-sales /var/log/hermes-sales
[[ ! -e "$RELEASE" ]] || { echo 'release already exists' >&2; exit 1; }
install -d -o hermes-sales -g hermes-sales -m 0750 "$RELEASE"
tar -xzf "$RELEASE_ARCHIVE" -C "$RELEASE"
python3 -m venv "$RELEASE/.venv"
"$RELEASE/.venv/bin/pip" install --no-input "$RELEASE"
chown -R hermes-sales:hermes-sales "$RELEASE"
ln -sfnT "$RELEASE" "$BASE/candidate"
"$BASE/candidate/.venv/bin/python" -m compileall -q "$BASE/candidate/src"
ln -sfnT "$RELEASE" "$BASE/current"
systemctl daemon-reload
systemctl restart hermes-sales
printf 'installed_release=%s\n' "$RELEASE"
