#!/usr/bin/env bash
set -euo pipefail

ENV_FILE=${1:-/etc/hermes-sales/hermes-sales.env}
fail(){ printf 'FAIL: %s\n' "$*" >&2; exit 1; }
pass(){ printf 'PASS: %s\n' "$*"; }

[[ $(id -u) -eq 0 ]] || fail 'run as root'
[[ -r "$ENV_FILE" ]] || fail "environment file missing: $ENV_FILE"
for command in python3 nginx systemctl curl openssl; do command -v "$command" >/dev/null || fail "command missing: $command"; done
source /etc/os-release
[[ ${ID:-} == ol && ${VERSION_ID%%.*} == 9 ]] || fail "expected Oracle Linux 9; got ${PRETTY_NAME:-unknown}"
free_mb=$(df -Pm /opt | awk 'NR==2{print $4}')
[[ $free_mb -ge 2048 ]] || fail 'less than 2GB free under /opt'
set -a; source "$ENV_FILE"; set +a
[[ ${HERMES_DB_USER:-} == HERMESUSER ]] || fail 'HERMES_DB_USER must be HERMESUSER'
[[ -r ${HERMES_DB_PASSWORD_FILE:-/nonexistent} ]] || fail 'DB password file missing or unreadable'
[[ -r ${TNS_ADMIN:-/nonexistent}/tnsnames.ora ]] || fail 'Wallet tnsnames.ora missing'
[[ ${HERMES_BIND_HOST:-} == 127.0.0.1 ]] || fail 'application must bind localhost'
ss -ltn | grep -q ':8080 ' && fail 'port 8080 already in use' || true
nginx -t
pass 'OS, disk, commands, environment, wallet, bind and nginx checks'
