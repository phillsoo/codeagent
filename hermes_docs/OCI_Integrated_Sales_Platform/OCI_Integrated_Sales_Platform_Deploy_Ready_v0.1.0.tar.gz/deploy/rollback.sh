#!/usr/bin/env bash
set -euo pipefail

BASE=/opt/hermes-sales
CURRENT=$(readlink -f "$BASE/current" || true)
PREVIOUS=${1:-}
[[ $(id -u) -eq 0 ]] || { echo 'run as root' >&2; exit 1; }
if [[ -z "$PREVIOUS" ]]; then
  PREVIOUS=$(find "$BASE/releases" -mindepth 1 -maxdepth 1 -type d ! -path "$CURRENT" -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)
fi
[[ -n "$PREVIOUS" && -d "$PREVIOUS" ]] || { echo 'previous release not found' >&2; exit 1; }
ln -sfnT "$PREVIOUS" "$BASE/current"
systemctl restart hermes-sales
"$(dirname "$0")/verify.sh"
printf 'rolled_back_from=%s\nrolled_back_to=%s\n' "$CURRENT" "$PREVIOUS"
