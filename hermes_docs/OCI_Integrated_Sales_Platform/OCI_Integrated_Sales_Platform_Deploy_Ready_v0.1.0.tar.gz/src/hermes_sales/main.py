from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from threading import Lock
from typing import Any
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

APP_NAME = "OCI Integrated Sales Platform"
VERSION = "0.1.0"
ROOT = Path(__file__).resolve().parent
DB_PATH = os.getenv("HERMES_DB_PATH", ":memory:")

app = FastAPI(title=APP_NAME, version=VERSION)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
_db = sqlite3.connect(DB_PATH, check_same_thread=False)
_db.row_factory = sqlite3.Row
_lock = Lock()


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def init_db() -> None:
    _db.executescript(
        """
        CREATE TABLE IF NOT EXISTS accounts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          tier TEXT, play TEXT, owner TEXT, status TEXT NOT NULL DEFAULT 'active',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS consumption(
          usage_key TEXT PRIMARY KEY, usage_date TEXT NOT NULL, service TEXT NOT NULL,
          cost TEXT NOT NULL, currency TEXT NOT NULL, unit TEXT NOT NULL,
          source_time TEXT NOT NULL, ingested_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS weekly(
          id INTEGER PRIMARY KEY AUTOINCREMENT, root_id INTEGER, week_start TEXT NOT NULL,
          owner TEXT NOT NULL, summary TEXT NOT NULL, status TEXT NOT NULL,
          revision INTEGER NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS demos(
          id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL,
          title TEXT NOT NULL, url TEXT NOT NULL, status TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        """
    )
    _db.commit()


init_db()

MODULES = [
    {"key": "crm", "label": "CRM"},
    {"key": "quotes", "label": "OCI 견적"},
    {"key": "consumption", "label": "Consumption"},
    {"key": "weekly", "label": "Weekly Report"},
    {
        "key": "demos",
        "label": "Demo Gallery",
        "children": [
            {"key": "oci-overview", "label": "OCI Overview"},
            {"key": "autonomous-ai-db", "label": "Autonomous AI Database"},
            {"key": "ai-data-platform", "label": "AI Data Platform"},
        ],
    },
]


class AccountCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    tier: str | None = None
    play: str | None = None
    owner: str | None = None


class AccountUpdate(BaseModel):
    name: str | None = None
    tier: str | None = None
    play: str | None = None
    owner: str | None = None


class QuoteRequest(BaseModel):
    part_number: str
    unit_price: Decimal
    quantity: int = Field(gt=0)
    term_months: int = Field(gt=0)
    discount_percent: Decimal = Field(ge=0, le=100)
    currency: str = Field(min_length=3, max_length=3)
    source_last_updated: str


class UsageRow(BaseModel):
    usage_key: str
    usage_date: str
    service: str
    cost: Decimal
    currency: str
    unit: str
    source_time: str


class WeeklyCreate(BaseModel):
    week_start: str
    owner: str
    summary: str


class WeeklyUpdate(BaseModel):
    summary: str


class DemoCreate(BaseModel):
    category: str
    title: str
    url: str


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/healthz")
def health() -> dict[str, str]:
    return {"status": "ok", "app": APP_NAME, "version": VERSION, "database_mode": "sqlite"}


@app.get("/api/modules")
def modules() -> dict[str, Any]:
    return {"modules": MODULES}


@app.get("/api/crm/accounts")
def list_accounts() -> dict[str, Any]:
    rows = _db.execute("SELECT * FROM accounts ORDER BY id DESC").fetchall()
    return {"items": [dict(r) for r in rows]}


@app.post("/api/crm/accounts", status_code=201)
def create_account(payload: AccountCreate) -> dict[str, Any]:
    stamp = now()
    with _lock:
        cur = _db.execute(
            "INSERT INTO accounts(name,tier,play,owner,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
            (payload.name, payload.tier, payload.play, payload.owner, "active", stamp, stamp),
        )
        _db.commit()
        row = _db.execute("SELECT * FROM accounts WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)


@app.put("/api/crm/accounts/{account_id}")
def update_account(account_id: int, payload: AccountUpdate) -> dict[str, Any]:
    existing = _db.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not existing:
        raise HTTPException(404, "account not found")
    data = dict(existing)
    for key, value in payload.model_dump(exclude_none=True).items():
        data[key] = value
    data["updated_at"] = now()
    with _lock:
        _db.execute("UPDATE accounts SET name=?,tier=?,play=?,owner=?,updated_at=? WHERE id=?", (data["name"], data["tier"], data["play"], data["owner"], data["updated_at"], account_id))
        _db.commit()
    return dict(_db.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone())


@app.delete("/api/crm/accounts/{account_id}")
def archive_account(account_id: int) -> dict[str, Any]:
    with _lock:
        _db.execute("UPDATE accounts SET status='archived',updated_at=? WHERE id=?", (now(), account_id))
        _db.commit()
    row = _db.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not row:
        raise HTTPException(404, "account not found")
    return dict(row)


@app.post("/api/quotes/calculate")
def calculate_quote(payload: QuoteRequest) -> dict[str, str]:
    gross = payload.unit_price * payload.quantity * payload.term_months
    total = gross * (Decimal("1") - payload.discount_percent / Decimal("100"))
    return {
        "part_number": payload.part_number,
        "total": str(total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)),
        "currency": payload.currency.upper(),
        "source_last_updated": payload.source_last_updated,
        "quoted_at": now(),
    }


@app.get("/api/consumption")
def list_consumption() -> dict[str, Any]:
    rows = _db.execute("SELECT * FROM consumption ORDER BY usage_date DESC").fetchall()
    return {"items": [dict(r) for r in rows], "freshness_checked_at": now()}


@app.post("/api/consumption")
def upsert_consumption(payload: UsageRow, response: Response) -> dict[str, Any]:
    exists = _db.execute("SELECT 1 FROM consumption WHERE usage_key=?", (payload.usage_key,)).fetchone()
    with _lock:
        _db.execute(
            "INSERT INTO consumption VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(usage_key) DO UPDATE SET usage_date=excluded.usage_date,service=excluded.service,cost=excluded.cost,currency=excluded.currency,unit=excluded.unit,source_time=excluded.source_time,ingested_at=excluded.ingested_at",
            (payload.usage_key, payload.usage_date, payload.service, str(payload.cost), payload.currency, payload.unit, payload.source_time, now()),
        )
        _db.commit()
    response.status_code = 200 if exists else 201
    return dict(_db.execute("SELECT * FROM consumption WHERE usage_key=?", (payload.usage_key,)).fetchone())


@app.get("/api/weekly")
def list_weekly() -> dict[str, Any]:
    return {"items": [dict(r) for r in _db.execute("SELECT * FROM weekly ORDER BY id DESC").fetchall()]}


@app.post("/api/weekly", status_code=201)
def create_weekly(payload: WeeklyCreate) -> dict[str, Any]:
    with _lock:
        cur = _db.execute("INSERT INTO weekly(root_id,week_start,owner,summary,status,revision,created_at) VALUES(NULL,?,?,?,?,?,?)", (payload.week_start, payload.owner, payload.summary, "draft", 1, now()))
        _db.execute("UPDATE weekly SET root_id=id WHERE id=?", (cur.lastrowid,))
        _db.commit()
    return dict(_db.execute("SELECT * FROM weekly WHERE id=?", (cur.lastrowid,)).fetchone())


@app.post("/api/weekly/{report_id}/approve")
def approve_weekly(report_id: int) -> dict[str, Any]:
    with _lock:
        _db.execute("UPDATE weekly SET status='approved' WHERE id=?", (report_id,))
        _db.commit()
    row = _db.execute("SELECT * FROM weekly WHERE id=?", (report_id,)).fetchone()
    if not row:
        raise HTTPException(404, "report not found")
    return dict(row)


@app.put("/api/weekly/{report_id}")
def update_weekly(report_id: int, payload: WeeklyUpdate) -> dict[str, Any]:
    old = _db.execute("SELECT * FROM weekly WHERE id=?", (report_id,)).fetchone()
    if not old:
        raise HTTPException(404, "report not found")
    if old["status"] == "approved":
        with _lock:
            cur = _db.execute("INSERT INTO weekly(root_id,week_start,owner,summary,status,revision,created_at) VALUES(?,?,?,?,?,?,?)", (old["root_id"], old["week_start"], old["owner"], payload.summary, "draft", old["revision"] + 1, now()))
            _db.commit()
        return dict(_db.execute("SELECT * FROM weekly WHERE id=?", (cur.lastrowid,)).fetchone())
    with _lock:
        _db.execute("UPDATE weekly SET summary=? WHERE id=?", (payload.summary, report_id))
        _db.commit()
    return dict(_db.execute("SELECT * FROM weekly WHERE id=?", (report_id,)).fetchone())


@app.get("/api/demos")
def list_demos() -> dict[str, Any]:
    return {"items": [dict(r) for r in _db.execute("SELECT * FROM demos ORDER BY id DESC").fetchall()]}


@app.post("/api/demos", status_code=201)
def create_demo(payload: DemoCreate) -> dict[str, Any]:
    parsed = urlparse(payload.url)
    host = (parsed.hostname or "").lower()
    allowed = ("oracle.com", "oraclecloud.com")
    if parsed.scheme != "https" or not any(host == item or host.endswith("." + item) for item in allowed):
        raise HTTPException(422, "demo URL host is not allowlisted")
    if payload.category not in {"oci-overview", "autonomous-ai-db", "ai-data-platform"}:
        raise HTTPException(422, "invalid demo category")
    with _lock:
        cur = _db.execute("INSERT INTO demos(category,title,url,status,created_at) VALUES(?,?,?,?,?)", (payload.category, payload.title, payload.url, "ready", now()))
        _db.commit()
    return dict(_db.execute("SELECT * FROM demos WHERE id=?", (cur.lastrowid,)).fetchone())
