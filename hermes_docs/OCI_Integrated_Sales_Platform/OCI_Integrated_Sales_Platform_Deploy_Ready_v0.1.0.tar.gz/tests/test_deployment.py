from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_deployment_package_contains_required_artifacts():
    required = [
        'db/001_schema_oracle.sql', 'db/002_seed_reference.sql',
        'deploy/preflight.sh', 'deploy/configure_host.sh', 'deploy/install.sh', 'deploy/verify.sh',
        'deploy/rollback.sh', 'deploy/hermes-sales.service',
        'deploy/nginx-hermes-sales.conf', '.env.example', 'README.md',
    ]
    for relative in required:
        assert (ROOT / relative).is_file(), relative


def test_nginx_binds_tls_and_application_binds_localhost():
    nginx = (ROOT / 'deploy/nginx-hermes-sales.conf').read_text()
    service = (ROOT / 'deploy/hermes-sales.service').read_text()
    assert 'listen 443 ssl' in nginx
    assert 'proxy_pass http://127.0.0.1:8080' in nginx
    assert '--host 127.0.0.1' in service
    assert 'EnvironmentFile=/etc/hermes-sales/hermes-sales.env' in service


def test_scripts_are_fail_fast_and_do_not_embed_target_credentials():
    for name in ['preflight.sh', 'configure_host.sh', 'install.sh', 'verify.sh', 'rollback.sh']:
        text = (ROOT / 'deploy' / name).read_text()
        assert 'set -euo pipefail' in text
        assert 'HERMESUSER.password' not in text
        assert '217.142.147.141' not in text


def test_oracle_schema_has_all_modules_audit_and_migration_journal():
    ddl = (ROOT / 'db/001_schema_oracle.sql').read_text().upper()
    for table in ['CRM_ACCOUNTS', 'PRICE_CATALOG_VERSIONS', 'QUOTES', 'USAGE_DAILY', 'WEEKLY_REPORTS', 'DEMO_ITEMS', 'AUDIT_EVENTS', 'MIGRATION_JOURNAL']:
        assert f'CREATE TABLE {table}' in ddl
    assert 'NUMBER(38, 10)' in ddl
    assert 'TIMESTAMP WITH TIME ZONE' in ddl
