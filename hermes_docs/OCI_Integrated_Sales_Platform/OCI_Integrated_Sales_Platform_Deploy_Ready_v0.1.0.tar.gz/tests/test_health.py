from fastapi.testclient import TestClient

from hermes_sales.main import app

client = TestClient(app)


def test_health_reports_version_and_database_mode():
    response = client.get('/healthz')
    assert response.status_code == 200
    assert response.json() == {
        'status': 'ok',
        'app': 'OCI Integrated Sales Platform',
        'version': '0.1.0',
        'database_mode': 'sqlite',
    }


def test_dashboard_exposes_five_modules_and_demo_children():
    data = client.get('/api/modules').json()
    assert [m['key'] for m in data['modules']] == [
        'crm', 'quotes', 'consumption', 'weekly', 'demos'
    ]
    assert [x['key'] for x in data['modules'][-1]['children']] == [
        'oci-overview', 'autonomous-ai-db', 'ai-data-platform'
    ]


def test_index_contains_navigation_shell():
    text = client.get('/').text
    for label in ['CRM', 'OCI 견적', 'Consumption', 'Weekly Report', 'Demo Gallery']:
        assert label in text
