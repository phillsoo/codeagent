# OCI Integrated Sales Platform Implementation Plan

> **For Hermes:** Implement task-by-task with strict TDD, then independent security/quality review.

**Goal:** FY27 Account 기반 CRM, OCI 가격 견적, OCI Consumption, Weekly Report, Demo Gallery를 단일 웹 애플리케이션으로 제공하고 ADBHERMES와 Oracle Linux 9 웹 서버에 승인 즉시 배포할 수 있는 패키지를 준비한다.

**Architecture:** 1 OCPU/12GB 환경에 맞춘 FastAPI 모놀리스와 정적 SPA를 사용한다. 데이터 계층은 repository interface로 분리해 로컬 SQLite 시험과 OCI Autonomous AI Database 운영을 같은 API로 지원한다. Nginx는 TLS reverse proxy, systemd는 프로세스 관리, OCI IAM/Identity Domain OIDC는 운영 인증의 목표 구조로 둔다.

**Tech Stack:** Python 3.11, FastAPI, SQLAlchemy 2, python-oracledb, Pydantic Settings, vanilla JS/CSS, pytest, Alembic/SQL migration, Nginx, systemd, OCI CLI/SDK.

---

## Scope and constraints

- 메인 메뉴: CRM, OCI 견적, OCI Consumption, Weekly Report, Demo Gallery.
- Demo 하위 메뉴: OCI Overview, Autonomous AI Database(Select AI/Select AI Agent), AI Data Platform.
- 운영 DB: `ADBHERMES`, 운영 사용자: `HERMESUSER`.
- Account 원본 고객명은 공개 GitHub에 포함하지 않는다. import template과 집계만 저장한다.
- 가격은 공식 OCI Price List/API의 버전·수집시각·통화·단위를 함께 저장한다.
- Consumption은 OCI Usage/Cost Analysis 또는 Usage Reports에서 수집하며 지연시간과 기준시각을 표시한다.
- 실제 배포, DB migration, IAM/네트워크 변경은 별도 승인 전 금지한다.

## Task 1 — Application foundation

**Files**
- Create: `pyproject.toml`, `src/hermes_sales/main.py`, `src/hermes_sales/config.py`
- Test: `tests/test_health.py`

**Steps**
1. `/healthz`가 app/version/db mode를 반환하는 실패 테스트 작성.
2. `pytest tests/test_health.py -v`로 RED 확인.
3. FastAPI app과 설정 모델 최소 구현.
4. 테스트 GREEN 및 전체 테스트 실행.

## Task 2 — Dashboard and navigation

**Files**
- Create: `src/hermes_sales/static/index.html`, `app.js`, `styles.css`
- Test: `tests/test_navigation.py`

**Steps**
1. 5개 메뉴와 Demo 3개 하위 메뉴 존재 테스트 작성·RED 확인.
2. 반응형 single-shell UI 구현.
3. `/` 및 static assets 테스트 GREEN.

## Task 3 — Domain models and repositories

**Files**
- Create: `src/hermes_sales/models.py`, `repositories.py`, `database.py`
- Test: `tests/test_repositories.py`

**Entities**
- `crm_accounts`, `crm_opportunities`, `crm_activities`
- `price_catalog_versions`, `price_items`, `quotes`, `quote_lines`
- `usage_daily`, `usage_sync_runs`
- `weekly_reports`, `weekly_report_items`
- `demo_items`, `audit_events`

**Steps**
1. SQLite repository CRUD·transaction rollback tests 작성·RED 확인.
2. SQLAlchemy models와 repository 최소 구현.
3. DML tests GREEN.

## Task 4 — CRM API and Account import

**Files**
- Create: `src/hermes_sales/api/crm.py`, `src/hermes_sales/services/account_import.py`, `templates/account_import_template.csv`
- Test: `tests/test_crm_api.py`, `tests/test_account_import.py`

**Acceptance**
- Account list/search/filter, create/update, soft archive.
- CSV/XLSX import 검증, 실제 고객 원본은 repository에 커밋하지 않음.
- Tier/Play/Owner 및 데이터 완성도 제공.

## Task 5 — Price catalog and quote API

**Files**
- Create: `src/hermes_sales/api/pricing.py`, `services/pricing_sync.py`
- Test: `tests/test_pricing.py`

**Acceptance**
- price version, part number, currency, unit, effective timestamp 저장.
- Quote header/line 계산은 Decimal 사용.
- discount, quantity, monthly/annual totals와 stale-price 경고.
- 실제 OCI API 호출은 adapter interface로 격리하고 fixture로 시험.

## Task 6 — Consumption API

**Files**
- Create: `src/hermes_sales/api/consumption.py`, `services/usage_sync.py`
- Test: `tests/test_consumption.py`

**Acceptance**
- 날짜/서비스/compartment별 actual cost·usage 집계.
- source timestamp, ingestion timestamp, currency, unit 저장.
- 재수집 idempotency와 지연시간 표시.

## Task 7 — Weekly Report API

**Files**
- Create: `src/hermes_sales/api/weekly.py`
- Test: `tests/test_weekly.py`

**Acceptance**
- 기간, 담당자, 성과, 이슈, 다음 주 계획 CRUD.
- draft/submitted/approved 상태와 변경 감사.
- 승인된 보고서는 수정 대신 새 revision 생성.

## Task 8 — Demo Gallery API

**Files**
- Create: `src/hermes_sales/api/demos.py`
- Test: `tests/test_demos.py`

**Acceptance**
- 카테고리 3개, 설명, 링크, 이미지 URL, 상태, 담당자 관리.
- 외부 URL allowlist 검증.
- Demo 실행 환경은 운영 CRM 데이터와 분리.

## Task 9 — Oracle schema and migration

**Files**
- Create: `db/001_schema.sql`, `db/002_seed_demo_categories.sql`, `scripts/db_preflight.py`, `scripts/db_migrate.py`
- Test: `tests/test_oracle_sql_contract.py`

**Acceptance**
- Oracle 호환 DDL, PK/FK/index/check constraint, timestamp with time zone.
- migration journal과 재실행 안전성.
- DB 비밀번호·Wallet 경로는 환경변수/보안 파일 참조만 사용.
- 실제 ADB 적용은 승인 전 금지.

## Task 10 — Deployment and rollback package

**Files**
- Create: `deploy/hermes-sales.service`, `deploy/nginx-hermes-sales.conf`, `deploy/install.sh`, `deploy/preflight.sh`, `deploy/verify.sh`, `deploy/rollback.sh`, `.env.example`, `DEPLOYMENT.md`
- Test: `tests/test_deployment_artifacts.py`

**Acceptance**
- Oracle Linux 9, Python venv, systemd, Nginx 지원.
- app은 localhost에만 bind, 외부는 443 reverse proxy.
- preflight에서 OS/CPU/memory/disk/ports/Wallet/DB 연결/백업 확인.
- release directory + `current` symlink로 원자적 전환·롤백.
- 네트워크 변경은 명령 예시만 제공하고 자동 실행 금지.

## Task 11 — Security and audit

**Files**
- Create: `SECURITY.md`, `src/hermes_sales/security.py`
- Test: `tests/test_security.py`

**Acceptance**
- 운영은 OCI IAM Identity Domain OIDC 전제.
- roles: Admin, Sales Manager, Sales Rep, Viewer.
- CRUD audit event, CSRF/security headers, input limits.
- 비밀정보·Wallet·고객 데이터가 Git에 포함되지 않는 검증.

## Task 12 — Full verification

1. `pytest -q` — 전체 GREEN.
2. `python -m compileall src scripts` — 성공.
3. 로컬 SQLite 모드로 서버 기동.
4. `/healthz`, `/api/modules`, 각 모듈 list endpoint smoke test.
5. 정적 UI에서 5개 메뉴와 Demo 3개 하위 메뉴 렌더링 확인.
6. `git status`, secret scan, dependency audit 수행.
7. 실제 배포용 blocker: SSH private key, HERMESUSER credential, 실제 schema 권한, TLS certificate, NSG/443 승인 기록.

## Deployment approval gate

- 정확한 SSH 사용자와 private key 경로
- 유지보수 창 및 허용 중단 시간
- DB migration/backup 승인
- HERMESUSER 최소 권한 확인
- 443 ingress와 22/8765/3389/1521 축소 승인
- TLS DNS/certificate
- 검수자 승인과 rollback 담당자
