# TDD Log

## Slice 1 — health, menu shell, module behavior

### RED
- Command: `.venv/bin/pytest -q`
- Result: exit 2; `ModuleNotFoundError: No module named 'hermes_sales'`
- Collection errors: 2

### GREEN
- Implemented FastAPI app, SQLite repository, five-module API/UI.
- Command: `.venv/bin/pytest -q`
- Result: 8 passed, 0 failed.

## Slice 2 — deploy package and Oracle schema

### RED
- Command: `.venv/bin/pytest -q tests/test_deployment.py`
- Result: 4 failed; required DDL/deploy artifacts did not exist.

### GREEN
- Implemented Oracle schema, seed, environment template, systemd, Nginx TLS, and preflight/install/verify/rollback scripts.
- Command: `.venv/bin/pytest -q`
- Result: 12 passed, 0 failed; clean run after aligning Starlette test dependency with `httpx2>=2,<3`.
- Clean wheel verification: installed `hermes_sales_platform-0.1.0-py3-none-any.whl` in a new venv; import PASS; `/healthz` returned HTTP 200.

## Slice 3 — Demo URL scheme hardening

### RED
- Added a `javascript://docs.oracle.com/...` case; endpoint incorrectly returned HTTP 201.

### GREEN
- Restricted Demo URLs to HTTPS plus the Oracle hostname allowlist.
- Full result: 12 passed, 0 failed; Ruff PASS.

## Slice 4 — Independent review findings

### RED
- Negative and unbounded scientific-notation unit prices were accepted.
- Invalid `source_last_updated` values were accepted.
- Re-editing the same approved root generated duplicate revision 2.
- Default environment implied Oracle production readiness while v0.1.0 uses SQLite.

### GREEN
- Added bounded positive Decimal validation and datetime validation.
- Revision allocation now uses `MAX(revision) + 1` inside the same lock and has a uniqueness constraint.
- Default environment is explicitly preview/SQLite; production preflight fails closed until the Oracle runtime adapter is implemented and verified.
- Full result: 14 passed, 0 failed; Ruff and shell syntax PASS.

## Slice 5 — Independent QA security hardening

### RED
- Root preflight executed environment-file contents; installer lacked mandatory checksum and non-privileged install; rollback accepted paths outside the release root.
- Nginx template could expose unauthenticated Preview APIs remotely.
- Demo URL validation did not reject userinfo, non-443 ports or fragments.

### GREEN
- Added strict non-executing env parser with root/0600 checks.
- Added wheel SHA-256 verification, `hermes-sales` unprivileged installation, rollback containment and failed-health automatic app restore.
- Added Nginx unknown-host 444 and remote deny; production preflight is explicit NO-GO.
- Added Demo HTTPS/no-userinfo/443-only/no-fragment checks and locked Consumption existence check with upsert.
- Version raised to v0.1.1 Preview. Full result: 15 passed, 0 failed; Ruff and shell syntax PASS.
