#!/usr/bin/env bash
set -euo pipefail

WHEEL=${1:?usage: install.sh WHEEL SHA256 VERSION}
EXPECTED_SHA256=${2:?usage: install.sh WHEEL SHA256 VERSION}
VERSION=${3:?usage: install.sh WHEEL SHA256 VERSION}
BASE=/opt/hermes-sales
RELEASE="$BASE/releases/$VERSION"
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ $(id -u) -eq 0 ]] || { echo 'run as root' >&2; exit 1; }
[[ -f "$WHEEL" && ! -L "$WHEEL" ]] || { echo 'regular wheel file required' >&2; exit 1; }
[[ $(basename "$WHEEL") == hermes_sales_platform-*.whl ]] || { echo 'unexpected wheel name' >&2; exit 1; }
[[ "$EXPECTED_SHA256" =~ ^[0-9a-f]{64}$ ]] || { echo 'invalid SHA-256' >&2; exit 1; }
printf '%s  %s\n' "$EXPECTED_SHA256" "$WHEEL" | sha256sum -c -
[[ "$VERSION" =~ ^[0-9A-Za-z._-]+$ ]] || { echo 'invalid version' >&2; exit 1; }
getent passwd hermes-sales >/dev/null || useradd --system --home-dir /var/lib/hermes-sales --shell /sbin/nologin hermes-sales
install -d -o hermes-sales -g hermes-sales -m 0750 "$BASE/releases" /var/lib/hermes-sales /var/log/hermes-sales
[[ ! -e "$RELEASE" ]] || { echo 'release already exists' >&2; exit 1; }
install -d -o hermes-sales -g hermes-sales -m 0750 "$RELEASE"
python3 -m venv "$RELEASE/.venv"
chown -R hermes-sales:hermes-sales "$RELEASE"
runuser -u hermes-sales -- "$RELEASE/.venv/bin/pip" install --no-input --no-index "$WHEEL"
runuser -u hermes-sales -- "$RELEASE/.venv/bin/python" -c 'import hermes_sales; print(hermes_sales.__version__)'
OLD=$(readlink -f "$BASE/current" || true)
ln -sfnT "$RELEASE" "$BASE/current"
systemctl daemon-reload
if ! systemctl restart hermes-sales || ! "$SCRIPT_DIR/verify.sh"; then
  if [[ -n "$OLD" && "$OLD" == "$BASE"/releases/* && -d "$OLD" ]]; then
    ln -sfnT "$OLD" "$BASE/current"
    systemctl restart hermes-sales || true
  fi
  echo 'installation verification failed; previous release restored when available' >&2
  exit 1
fi
printf 'installed_release=%s\n' "$RELEASE"
