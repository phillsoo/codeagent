#!/usr/bin/env bash
set -euo pipefail

ENV_FILE=${1:-/etc/hermes-sales/hermes-sales.env}
fail(){ printf 'FAIL: %s\n' "$*" >&2; exit 1; }
pass(){ printf 'PASS: %s\n' "$*"; }
get_env(){
  python3 - "$ENV_FILE" "$1" <<'PY'
import re,sys
path,key=sys.argv[1:]
value=None
for raw in open(path, encoding='utf-8'):
    line=raw.strip()
    if not line or line.startswith('#'): continue
    if not re.fullmatch(r'[A-Z][A-Z0-9_]*=[^\x00\r\n]*', line):
        raise SystemExit('invalid environment line')
    k,v=line.split('=',1)
    if k==key: value=v
if value is None: raise SystemExit(f'missing environment key: {key}')
print(value)
PY
}

[[ $(id -u) -eq 0 ]] || fail 'run as root'
[[ -r "$ENV_FILE" ]] || fail "environment file missing: $ENV_FILE"
[[ $(stat -c %U "$ENV_FILE") == root ]] || fail 'environment file must be owned by root'
[[ $(stat -c %a "$ENV_FILE") == 600 ]] || fail 'environment file mode must be 600'
for command in python3 nginx systemctl curl openssl ss; do command -v "$command" >/dev/null || fail "command missing: $command"; done
source /etc/os-release
[[ ${ID:-} == ol && ${VERSION_ID%%.*} == 9 ]] || fail "expected Oracle Linux 9; got ${PRETTY_NAME:-unknown}"
free_mb=$(df -Pm /opt | awk 'NR==2{print $4}')
[[ $free_mb -ge 2048 ]] || fail 'less than 2GB free under /opt'
HERMES_ENV=$(get_env HERMES_ENV)
HERMES_DB_MODE=$(get_env HERMES_DB_MODE)
HERMES_BIND_HOST=$(get_env HERMES_BIND_HOST)
[[ $HERMES_BIND_HOST == 127.0.0.1 ]] || fail 'application must bind localhost'
[[ $HERMES_ENV == production && $HERMES_DB_MODE == oracle ]] || fail 'preview configuration cannot be deployed to production'
fail 'NO-GO: Oracle runtime adapter, OIDC/RBAC, DB smoke test and change approval are not verified in v0.1.1'
