#!/usr/bin/env bash
set -euo pipefail

BASE=/opt/hermes-sales
CURRENT=$(readlink -f "$BASE/current" || true)
PREVIOUS=${1:-}
[[ $(id -u) -eq 0 ]] || { echo 'run as root' >&2; exit 1; }
if [[ -z "$PREVIOUS" ]]; then
  PREVIOUS=$(find "$BASE/releases" -mindepth 1 -maxdepth 1 -type d ! -path "$CURRENT" -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)
fi
PREVIOUS=$(realpath -e "$PREVIOUS" 2>/dev/null || true)
[[ -n "$PREVIOUS" && -d "$PREVIOUS" ]] || { echo 'previous release not found' >&2; exit 1; }
[[ "$PREVIOUS" == "$BASE"/releases/* ]] || { echo 'rollback target must be under releases' >&2; exit 1; }
ln -sfnT "$PREVIOUS" "$BASE/current"
if ! systemctl restart hermes-sales || ! "$(dirname "$0")/verify.sh"; then
  if [[ -n "$CURRENT" && "$CURRENT" == "$BASE"/releases/* && -d "$CURRENT" ]]; then
    ln -sfnT "$CURRENT" "$BASE/current"
    systemctl restart hermes-sales || true
  fi
  echo 'rollback verification failed; original release restored' >&2
  exit 1
fi
printf 'rolled_back_from=%s\nrolled_back_to=%s\n' "$CURRENT" "$PREVIOUS"
