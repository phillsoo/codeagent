#!/usr/bin/env bash
set -euo pipefail

BASE_URL=${1:-http://127.0.0.1:8080}
expected='"status":"ok"'
for attempt in {1..20}; do
  body=$(curl -fsS --max-time 3 "$BASE_URL/healthz" || true)
  if [[ "$body" == *"$expected"* ]]; then
    curl -fsS --max-time 5 "$BASE_URL/api/modules" | grep -q 'Demo Gallery'
    printf 'PASS: health and five-module API verified\n'
    exit 0
  fi
  sleep 1
done
printf 'FAIL: application health did not become ready\n' >&2
exit 1
