from fastapi.testclient import TestClient

from hermes_sales.main import app

client = TestClient(app)


def test_crm_crud_and_soft_archive():
    created = client.post('/api/crm/accounts', json={
        'name': 'Test Account', 'tier': 'T2', 'play': 'AI Data Platform', 'owner': 'tester'
    })
    assert created.status_code == 201
    account = created.json()
    assert account['status'] == 'active'
    updated = client.put(f"/api/crm/accounts/{account['id']}", json={'tier': 'T1'})
    assert updated.status_code == 200
    assert updated.json()['tier'] == 'T1'
    archived = client.delete(f"/api/crm/accounts/{account['id']}")
    assert archived.status_code == 200
    assert archived.json()['status'] == 'archived'


def test_quote_decimal_totals_and_snapshot_metadata():
    response = client.post('/api/quotes/calculate', json={
        'part_number': 'TEST-001', 'unit_price': '10.25', 'quantity': 2,
        'term_months': 12, 'discount_percent': '10', 'currency': 'USD',
        'source_last_updated': '2026-07-16T13:52:41.483Z'
    })
    assert response.status_code == 200
    assert response.json()['total'] == '221.40'
    assert response.json()['currency'] == 'USD'


def test_quote_rejects_invalid_price_and_snapshot_time():
    base = {
        'part_number': 'TEST-001', 'unit_price': '10.25', 'quantity': 1,
        'term_months': 1, 'discount_percent': '0', 'currency': 'USD',
        'source_last_updated': '2026-07-16T13:52:41Z'
    }
    assert client.post('/api/quotes/calculate', json={**base, 'unit_price': '-1'}).status_code == 422
    assert client.post('/api/quotes/calculate', json={**base, 'unit_price': '1e999999'}).status_code == 422
    assert client.post('/api/quotes/calculate', json={**base, 'source_last_updated': 'not-a-date'}).status_code == 422


def test_usage_upsert_is_idempotent_and_reports_freshness():
    row = {'usage_key':'k1','usage_date':'2026-07-17','service':'Compute','cost':'3.50','currency':'USD','unit':'OCPU Hour','source_time':'2026-07-18T00:00:00Z'}
    assert client.post('/api/consumption', json=row).status_code == 201
    assert client.post('/api/consumption', json={**row, 'cost':'4.00'}).status_code == 200
    data = client.get('/api/consumption').json()
    assert len([x for x in data['items'] if x['usage_key']=='k1']) == 1
    assert data['items'][0]['cost'] == '4.00'
    assert 'ingested_at' in data['items'][0]


def test_weekly_approved_update_creates_revision():
    created = client.post('/api/weekly', json={'week_start':'2026-07-13','owner':'tester','summary':'draft'}).json()
    client.post(f"/api/weekly/{created['id']}/approve")
    revised = client.put(f"/api/weekly/{created['id']}", json={'summary':'revised'}).json()
    assert revised['revision'] == 2
    assert revised['status'] == 'draft'
    revised_again = client.put(f"/api/weekly/{created['id']}", json={'summary':'revised again'}).json()
    assert revised_again['revision'] == 3


def test_demo_external_url_requires_allowlist():
    bad = client.post('/api/demos', json={'category':'oci-overview','title':'bad','url':'https://evil.example/demo'})
    assert bad.status_code == 422
    bad_scheme = client.post('/api/demos', json={'category':'oci-overview','title':'bad scheme','url':'javascript://docs.oracle.com/demo'})
    assert bad_scheme.status_code == 422
    bad_userinfo = client.post('/api/demos', json={'category':'oci-overview','title':'bad userinfo','url':'https://attacker@docs.oracle.com/demo'})
    assert bad_userinfo.status_code == 422
    bad_port = client.post('/api/demos', json={'category':'oci-overview','title':'bad port','url':'https://docs.oracle.com:8443/demo'})
    assert bad_port.status_code == 422
    good = client.post('/api/demos', json={'category':'oci-overview','title':'good','url':'https://docs.oracle.com/demo'})
    assert good.status_code == 201
